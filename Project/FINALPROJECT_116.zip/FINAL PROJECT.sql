-- Create the database for the to-do list app
CREATE DATABASE IF NOT EXISTS todo_list_db;

-- Use the created database
USE todo_list_db;

-- Create the tasks table
CREATE TABLE IF NOT EXISTS tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,  -- Auto-incrementing primary key for each task
    task_name VARCHAR(255) NOT NULL UNIQUE,  -- Task name, must be unique and not null
    status ENUM('Pending', 'Done') NOT NULL DEFAULT 'Pending'  -- Task status, either 'Pending' or 'Done'
);