<?php
// Include the Contact class to access database operations
require_once __DIR__ . '/../app/Contact.php';

// Create a new instance of the Contact class
$contact = new Contact();

// Initialize an empty array to hold validation errors
$errors = [];

// Check if the form is submitted using POST method
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Trim whitespace from user input or set to empty if not set
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');

    // 1. Check for empty fields
    if (empty($name) || empty($phone) || empty($email)) {
        $errors[] = "Please fill in all the fields.";
    } else {
        // 2. Validate phone: only numbers allowed
        if (!preg_match('/^[0-9]+$/', $phone)) {
            $errors[] = "Phone must contain numbers only.";
        }

        // 3. Validate email using PHP's built-in filter
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Invalid email address.";
        }
    }

    // 4. If no validation errors, create a new contact and redirect to dashboard
    if (empty($errors)) {
        $contact->create([
            'name' => $name,
            'phone' => $phone,
            'email' => $email
        ]);

        // Redirect to the main dashboard after successful creation
        header('Location: index.php');
        exit(); // Stop script execution to avoid further output
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Contact</title>
    <!-- Bootstrap CSS for styling -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h2>Add New Contact</h2>
    <!-- Back button to return to the main dashboard -->
    <a href="index.php" class="btn btn-secondary mb-3">← Back</a>

    <!-- Display validation errors if there are any -->
    <?php foreach ($errors as $error): ?>
        <div class="alert alert-danger">❌ <?= htmlspecialchars($error) ?></div>
    <?php endforeach; ?>

    <!-- Contact creation form -->
    <form method="POST" novalidate>
        <!-- Name field -->
        <div class="mb-3">
            <label for="name" class="form-label">Name *</label>
            <input type="text" name="name" id="name" class="form-control" required
                value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
        </div>

        <!-- Phone field: only numeric input accepted -->
        <div class="mb-3">
            <label for="phone" class="form-label">Phone *</label>
            <input type="tel" name="phone" id="phone" class="form-control" required pattern="[0-9]+"
                value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
        </div>

        <!-- Email field: must be a valid email format -->
        <div class="mb-3">
            <label for="email" class="form-label">Email *</label>
            <input type="email" name="email" id="email" class="form-control" required
                value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
        </div>

        <!-- Submit button -->
        <button type="submit" class="btn btn-success">Add Contact</button>
    </form>
</body>
</html>
