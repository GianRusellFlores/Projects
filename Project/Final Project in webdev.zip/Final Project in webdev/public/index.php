<?php
require_once __DIR__ . '/../app/Contact.php';  // Load the Contact class (which loads db.php internally)

// Create a new instance of the Contact class
$contact = new contact();

// Fetch all contacts from the database
$contacts = $contact->getAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Contact Manager</title>

  <!-- Bootstrap CSS for styling -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

  <!-- Optional: Your custom stylesheet -->
  <link rel="stylesheet" href="assets/style.css">
</head>
<body class="container mt-5">
  <h2>Contact Manager</h2>

  <!-- Button to go to add contact page -->
  <a href="add.php" class="btn btn-success mb-3">Add Contact</a>

  <!-- Contact list table -->
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Name</th>
        <th>Phone</th>
        <th>Email</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($contacts as $c): ?>
      <tr>
        <!-- Escape HTML characters for security -->
        <td><?= htmlspecialchars($c['name']) ?></td> 
        <td><?= htmlspecialchars($c['phone']) ?></td>
        <td><?= htmlspecialchars($c['email']) ?></td>
        <td>
          <!-- Edit button links to edit form with contact ID -->
          <a href="edit.php?id=<?= $c['id'] ?>" class="btn btn-warning btn-sm">Edit</a>

          <!-- Delete button links to delete script with contact ID -->
          <!-- Uses JavaScript confirm dialog to prevent accidental deletions -->
          <a href="delete.php?id=<?= $c['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this contact?')">Delete</a>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</body>
</html>
