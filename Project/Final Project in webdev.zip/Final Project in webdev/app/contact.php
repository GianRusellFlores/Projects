<?php
// Include the database connection configuration
require_once __DIR__ . '/../config/db.php';

// Define the Contact class to handle all contact-related operations
class Contact {
    // Private variable to hold the database connection
    private $conn;

    // Constructor: automatically called when an object is created
    public function __construct() {
        // Establish the database connection using the static method from the Database class
        $this->conn = Database::connect(); 
    }

    // Get all contacts from the database, ordered by newest first
    public function getAll() {
        // Prepare and execute the SQL query
        $stmt = $this->conn->query("SELECT * FROM contacts ORDER BY id DESC");
        // Return all results as an associative array
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get a single contact by its ID
    public function get($id) {
        // Prepare the SQL query with a placeholder
        $stmt = $this->conn->prepare("SELECT * FROM contacts WHERE id = ?");
        // Execute the query with the given ID
        $stmt->execute([$id]);
        // Return the fetched row as an associative array
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Create a new contact entry
    public function create($data) {
        // Prepare the insert SQL query with placeholders
        $stmt = $this->conn->prepare("INSERT INTO contacts (name, phone, email) VALUES (?, ?, ?)");
        // Execute the query with the data provided (name, phone, email)
        return $stmt->execute([
            $data['name'], 
            $data['phone'], 
            $data['email']
        ]);
    }

    // Update an existing contact with new data
    public function update($id, $data) {
        // Prepare the update SQL query
        $stmt = $this->conn->prepare("UPDATE contacts SET name = ?, phone = ?, email = ? WHERE id = ?");
        // Execute the query with the new data and the contact's ID
        return $stmt->execute([
            $data['name'], 
            $data['phone'], 
            $data['email'], 
            $id
        ]);
    }

    // Delete a contact based on its ID
    public function delete($id) {
        // Prepare the delete SQL query
        $stmt = $this->conn->prepare("DELETE FROM contacts WHERE id = ?");
        // Execute the query with the provided ID
        return $stmt->execute([$id]);
    }
}
