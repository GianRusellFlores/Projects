<?php
// Include the Contact class to perform database operations
require_once __DIR__ . '/../app/Contact.php';

// Create a new instance of the Contact class
$contact = new Contact();

// Initialize error array and success flag
$errors = [];
$success = false;

// Get the contact ID from the URL (GET request)
$id = $_GET['id'] ?? null;

// If no ID or contact not found in the database, show error
if (!$id || !$contact->get($id)) {
    die("Contact not found.");
}

// Retrieve existing contact data to pre-fill the form
$data = $contact->get($id);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get and sanitize user input
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');

    // 1. Check if any field is empty
    if (empty($name) || empty($phone) || empty($email)) {
        $errors[] = "Please fill in all the fields.";
    } else {
        // 2. Validate phone number (must be numeric)
        if (!preg_match('/^[0-9]+$/', $phone)) {
            $errors[] = "Phone must contain numbers only.";
        }

        // 3. Validate email format
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Invalid email address.";
        }
    }

    // 4. If no validation errors, update the contact in the database
    if (empty($errors)) {
        $contact->update($id, ['name' => $name, 'phone' => $phone, 'email' => $email]);
        $success = true;

        // Update form data with the new values
        $data = ['name' => $name, 'phone' => $phone, 'email' => $email];
    }
}
?>

<!-- HTML Page Starts -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Contact</title>

    <!-- Bootstrap for styling -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h2>Edit Contact</h2>

    <!-- Back to dashboard link -->
    <a href="index.php" class="btn btn-secondary mb-3">← Back</a>

    <!-- Success message -->
    <?php if ($success): ?>
        <div class="alert alert-success">✅ Contact updated successfully!</div>
    <?php endif; ?>

    <!-- Display any validation errors -->
    <?php foreach ($errors as $error): ?>
        <div class="alert alert-danger">❌ <?= htmlspecialchars($error) ?></div>
    <?php endforeach; ?>

    <!-- Edit contact form -->
    <form method="POST" novalidate>
        <!-- Name Field -->
        <div class="mb-3">
            <label for="name" class="form-label">Name *</label>
            <input type="text" name="name" id="name" class="form-control" required
                value="<?= htmlspecialchars($data['name'] ?? '') ?>">
        </div>

        <!-- Phone Field -->
        <div class="mb-3">
            <label for="phone" class="form-label">Phone *</label>
            <input type="tel" name="phone" id="phone" class="form-control" required pattern="[0-9]+"
                title="Only numbers allowed"
                value="<?= htmlspecialchars($data['phone'] ?? '') ?>">
        </div>

        <!-- Email Field -->
        <div class="mb-3">
            <label for="email" class="form-label">Email *</label>
            <input type="email" name="email" id="email" class="form-control" required
                value="<?= htmlspecialchars($data['email'] ?? '') ?>">
        </div>

        <!-- Submit Button -->
        <button type="submit" class="btn btn-primary">Update Contact</button>
    </form>
</body>
</html>
