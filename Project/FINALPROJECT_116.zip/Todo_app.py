import mysql.connector  # Importing the MySQL connector for database operations
import tkinter as tk  # Importing Tkinter for GUI development
from tkinter import messagebox, ttk  # Importing messagebox for pop-up messages and ttk for styled widgets


# ----------------- Database Setup -----------------
def connect_db():
    """
    Connects to the MySQL database.
    Returns a connection object if successful; otherwise, shows an error message.
    """
    try:
        # Connect to MySQL database
        conn = mysql.connector.connect(
            host="localhost",
            user="root",        
            password="root",    
            database="todo_list_db"  # Database name
        )
        return conn
    except mysql.connector.Error as e:
        # Display error message if connection fails
        messagebox.showerror("Database Error", f"Error: {e}")
        return None

def initialize_db():
    """
    Initializes the database by creating the tasks table if it doesn't already exist.
    """
    conn = connect_db()
    if conn:
        cursor = conn.cursor()
        # Create tasks table with columns: task_name and status
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS tasks (
                id INT AUTO_INCREMENT PRIMARY KEY,
                task_name VARCHAR(255) NOT NULL UNIQUE,
                status ENUM('Pending', 'Done') NOT NULL DEFAULT 'Pending'
            )
        ''')
        conn.commit()  # Save changes
        conn.close()   # Close connection

# ----------------- Functions -----------------
def add_task():
    """
    Adds a new task to the database.
    """
    task = entry_task.get().strip()  # Get task from entry box and remove leading/trailing spaces
    if not task:
        messagebox.showwarning("Warning", "Task cannot be empty!")  # Show warning if task is empty
        return

    conn = connect_db()
    if conn:
        cursor = conn.cursor()
        # Insert new task with 'Pending' status
        try:
            cursor.execute("INSERT INTO tasks (task_name, status) VALUES (%s, %s)", (task, "Pending"))
            conn.commit()
        except mysql.connector.Error as e:
            messagebox.showerror("Database Error", f"Error: {e}")
        conn.close()
        entry_task.delete(0, tk.END)  # Clear the input field
        refresh_tasks()  # Refresh the task list

def refresh_tasks():
    """
    Refreshes the task list displayed in the Treeview table.
    """
    for row in tree.get_children():
        tree.delete(row)  # Clear the Treeview table

    conn = connect_db() 
    if conn:
        cursor = conn.cursor()
        # Retrieve all tasks ordered by ID
        cursor.execute("SELECT task_name, status FROM tasks ORDER BY id")
        rows = cursor.fetchall()
        # Insert tasks into the Treeview
        for row in rows:
            tree.insert("", "end", values=row)
        conn.close()

def update_task():
    """
    Updates the selected task's name in the database and resets its status to 'Pending'.
    """
    selected_item = tree.selection()  # Get selected row
    if not selected_item:
        messagebox.showwarning("Warning", "No task selected!")  # Show warning if no task is selected
        return

    task_name = tree.item(selected_item)['values'][0]  # Get task name
    new_task_name = entry_task.get().strip()  # Get new task name

    if not new_task_name:
        messagebox.showwarning("Warning", "Task name cannot be empty!")  # Show warning if task name is empty
        return

    conn = connect_db()
    if conn:
        cursor = conn.cursor()
        # Update task name and reset status to 'Pending'
        cursor.execute("UPDATE tasks SET task_name = %s, status = 'Pending' WHERE task_name = %s", (new_task_name, task_name))
        conn.commit()
        conn.close()
        refresh_tasks()  # Refresh the task list
        entry_task.delete(0, tk.END)  # Clear the input field

def mark_done():
    """
    Marks the selected task as 'Done'.
    """
    selected_item = tree.selection()  # Get selected row
    if not selected_item:
        messagebox.showwarning("Warning", "No task selected!")  # Show warning if no task is selected
        return

    task_name = tree.item(selected_item)['values'][0]  # Get task name
    conn = connect_db()
    if conn:
        cursor = conn.cursor()
        # Update task status to 'Done'
        cursor.execute("UPDATE tasks SET status = 'Done' WHERE task_name = %s", (task_name,))
        conn.commit()
        conn.close()
        refresh_tasks()  # Refresh the task list

def delete_task():
    """
    Deletes the selected task from the database.
    """
    selected_item = tree.selection()  # Get selected row
    if not selected_item:
        messagebox.showwarning("Warning", "No task selected!")  # Show warning if no task is selected
        return

    task_name = tree.item(selected_item)['values'][0]  # Get task name
    conn = connect_db()
    if conn:
        cursor = conn.cursor()
        # Delete task from the database
        cursor.execute("DELETE FROM tasks WHERE task_name = %s", (task_name,))
        conn.commit()
        conn.close()
        refresh_tasks()  # Refresh the task list


# ----------------- GUI Layout -----------------
root = tk.Tk()
root.title("To-Do List App")  # Set window title
root.geometry("700x600")  # Set window size
root.configure(bg="#e6f7ff")  # Set background color

# Header
header = tk.Label(root, text="To-Do List Application", font=("Arial", 24, "bold"), bg="#e6f7ff", fg="#007acc")
header.pack(pady=10)

# Task Input Section
frame_input = tk.Frame(root, bg="#e6f7ff")
frame_input.pack(pady=10)
entry_task = tk.Entry(frame_input, width=40, font=("Arial", 14))  # Task input field
entry_task.grid(row=0, column=0, padx=5, pady=5)
btn_add = tk.Button(frame_input, text="Add Task", bg="#28a745", fg="white", font=("Arial", 12), command=add_task)
btn_add.grid(row=0, column=1, padx=5)

# Task Table with Scrollbar
frame_table = tk.Frame(root)
frame_table.pack(pady=10)

columns = ("Task", "Status")  # Remove "ID" column
tree = ttk.Treeview(frame_table, columns=columns, show="headings", height=15)
tree.heading("Task", text="Task")
tree.heading("Status", text="Status")

# Styling the Table
tree.column("Task", width=300, anchor="center")
tree.column("Status", width=300, anchor="center")
style = ttk.Style()
style.configure("Treeview", font=("Arial", 12))
style.configure("Treeview.Heading", font=("Arial", 14, "bold"))
tree.grid(row=0, column=0, sticky="nsew")

# Scrollbar
scrollbar = ttk.Scrollbar(frame_table, orient="vertical", command=tree.yview)
tree.configure(yscroll=scrollbar.set)
scrollbar.grid(row=0, column=1, sticky="ns")

# Buttons Section
frame_buttons = tk.Frame(root, bg="#e6f7ff")
frame_buttons.pack(pady=10)
btn_update = tk.Button(frame_buttons, text="Edit Task", bg="#ffc107", fg="white", font=("Arial", 12), command=update_task)
btn_update.grid(row=0, column=0, padx=5)
btn_done = tk.Button(frame_buttons, text="Mark as Done", bg="#17a2b8", fg="white", font=("Arial", 12), command=mark_done)
btn_done.grid(row=0, column=1, padx=5)
btn_delete = tk.Button(frame_buttons, text="Delete Task", bg="#dc3545", fg="white", font=("Arial", 12), command=delete_task)
btn_delete.grid(row=0, column=2, padx=5)

# Initialize Database and Load Tasks
initialize_db()
refresh_tasks()

# Start the main GUI loop
root.mainloop()
