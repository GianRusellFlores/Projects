<?php
// Include the Contact class from the app directory
require_once '../app/contact.php';

// Create a new instance of the Contact class
$contact = new Contact();

// Get the contact ID from the URL query parameter (?id=...)
$id = $_GET['id'];

// Call the delete method to remove the contact with the given ID
$contact->delete($id);

// Redirect back to the main contact list page after deletion
header('Location: index.php');
?>
