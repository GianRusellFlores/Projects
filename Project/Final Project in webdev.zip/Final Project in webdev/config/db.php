<?php
class Database {
    // Static method to establish a DB connection
    public static function connect() {
        $host = 'localhost';
        $dbname = 'contact_db';
        $user = 'root';
        $pass = '';
        try {
            // Create a new PDO instance and return it
            return new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
        } catch (PDOException $e) {
            // If connection fails, display error and stop script
            die("DB Connection Failed: " . $e->getMessage());
        }
    }
}
?>
