#include <iostream>
#include <string>
#include <stack>
#include <stdexcept>
#include <cctype>

using namespace std;

// Function to evaluate a basic logical operation between P and Q
bool evaluate_logic(bool p, bool q, const string& op) {
    if (op == "&") return p && q;
    if (op == "v") return p || q;
    if (op == "^") return p != q; // XOR
    if (op == "->") return !p || q; // Implication
    if (op == "<->") return p == q; // Biconditional
    throw invalid_argument("Invalid operator: " + op);
}

// Function to evaluate NOT operation
bool evaluate_not(bool value) {
    return !value;
}

// Helper function to check if the character is an operator
bool is_operator(char c) {
    return c == '&' || c == 'v' || c == '^' || c == '-' || c == '<';
}

// Function to get the precedence of operators
int precedence(const string& op) {
    if (op == "!" ) return 3;
    if (op == "&" ) return 2;
    if (op == "v" || op == "^") return 1;
    if (op == "->" || op == "<->") return 0;
    return -1;
}

// Function to apply the operator on two values
bool apply_operator(bool val1, bool val2, const string& op) {
    return evaluate_logic(val1, val2, op);
}

// Function to evaluate the expression inside parentheses
bool evaluate_expression(const string& expression, bool p, bool q) {
    stack<bool> values;
    stack<string> ops;
    bool value;
    string op;

    for (size_t i = 0; i < expression.size(); i++) {
        char current = expression[i];

        // Ignore spaces
        if (isspace(current)) continue;

        // If the current character is a P or Q, push its value onto the value stack
        if (current == 'P' || current == 'p') {
            values.push(p);
        } else if (current == 'Q' || current == 'q') {
            values.push(q);
        }
        // If it's an opening parenthesis, push it onto the operator stack
        else if (current == '(') {
            ops.push("(");
        }
        // If it's a closing parenthesis, solve the entire subexpression
        else if (current == ')') {
            while (!ops.empty() && ops.top() != "(") {
                op = ops.top(); ops.pop();
                bool val2 = values.top(); values.pop();
                bool val1 = values.top(); values.pop();
                values.push(apply_operator(val1, val2, op));
            }
            ops.pop(); // Pop '('
        }
        // If the current character is an operator
        else if (is_operator(current)) {
            // Handle multi-character operators
            string op(1, current);
            if (current == '-' && i + 1 < expression.size() && expression[i + 1] == '>') {
                op = "->";
                i++;
            } else if (current == '<' && i + 2 < expression.size() && expression[i + 1] == '-' && expression[i + 2] == '>') {
                op = "<->";
                i += 2;
            }

            // While the operator at the top of the ops stack has higher precedence, apply it
            while (!ops.empty() && precedence(ops.top()) >= precedence(op)) {
                string prev_op = ops.top(); ops.pop();
                bool val2 = values.top(); values.pop();
                bool val1 = values.top(); values.pop();
                values.push(apply_operator(val1, val2, prev_op));
            }
            ops.push(op);
        }
        // Handle NOT operator separately
        else if (current == '!') {
            if (expression[i + 1] == 'P' || expression[i + 1] == 'p') {
                values.push(evaluate_not(p));
                i++;
            } else if (expression[i + 1] == 'Q' || expression[i + 1] == 'q') {
                values.push(evaluate_not(q));
                i++;
            }
        }
    }

    // Apply remaining operators
    while (!ops.empty()) {
        op = ops.top(); ops.pop();
        bool val2 = values.top(); values.pop();
        bool val1 = values.top(); values.pop();
        values.push(apply_operator(val1, val2, op));
    }

    return values.top();
}

// Function to print the truth table
void print_truth_table(const string& expression) {
    // Print the header of the truth table
    cout << "P\tQ\t" << expression << endl;
    cout << "-------------------------" << endl;

    // Possible truth values for P and Q
    bool truth_values[4][2] = {
        {true, true},
        {true, false},
        {false, true},
        {false, false}
    };

    // Evaluate the expression for all combinations of P and Q
    for (int i = 0; i < 4; i++) {
        bool p = truth_values[i][0];
        bool q = truth_values[i][1];
        bool result;

        try {
            result = evaluate_expression(expression, p, q);
        } catch (const invalid_argument& e) {
            cout << e.what() << endl;
            return;
        }

        // Print the truth table row
        cout << (p ? "True" : "False") << "\t"
             << (q ? "True" : "False") << "\t"
             << (result ? "True" : "False") << endl;
    }
}

// Main program
int main() {
    cout << "Welcome to the Truth Table Generator!" << endl;
    cout << "Supported logical operators: AND (&), OR (v), XOR (^), NOT (!), Implication (->), Biconditional (<->)" << endl;

    // Ask for the logical expression from the user
    string user_input;
    cout << "Enter a logical expression involving P and Q:\n ";
    getline(cin, user_input);

    // Generate and display the truth table
    print_truth_table(user_input);

    return 0;
}
